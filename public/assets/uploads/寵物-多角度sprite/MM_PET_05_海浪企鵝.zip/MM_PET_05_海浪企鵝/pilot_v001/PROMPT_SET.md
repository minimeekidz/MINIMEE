# MM_PET_05 海浪企鵝 Pilot Prompt Set v001

生成方式：ChatGPT built-in image generation。  
身份參考：`MM_PET_05_front_neutral_standing_v001.png`。

## 所有圖共同身份鎖

```text
MM_PET_05 海浪企鵝；深海藍水滴形圓身；大白色臉區與白腹；短橙喙；橙色腳；頸部打結的藍色海浪披肩；腹部圓形藍色海浪徽章；短圓頭重比例；精緻清晰像素風；深色輪廓；左上45度光源。不可飛行；不可改物種、palette、披肩、徽章或比例；不可裁頭、披肩或腳；不可有場景、地面、投影、文字、logo、水印、UI、額外角色。
```

## 四方向 Walk Sheets

每張使用共同規格：

```text
同一角色兩個全身 walk frames 橫排。f01 為 contact／中性步，f02 為另一腳 passing step；腳底基線、身體中心、頭部尺寸與 silhouette 一致；只有輕微披肩延遲。高位俯視／近似等角地圖視角，看到少量頭頂與肩膊上平面。純 #FF00FF 背景；目標 1084×552；20px 外框、512×512 cell、20px gutter、512×512 cell、20px 外框；無標籤或格線。
```

- `front`：面向玩家，朝畫面下方移動；保留完整臉、白腹及海浪徽章。
- `back`：背向玩家，朝畫面上方移動；不可見臉、眼、喙、白臉或腹徽章；顯示披肩背面與雙翼。
- `left_side`：真左側面，喙與身體朝畫面左；白臉、白腹及徽章按側面透視縮窄。
- `right_side`：獨立繪製真右側面，喙與身體朝畫面右；不可把光影或像素細節機械鏡像。

## Emotion Board A

```text
4欄×3行、共12個同一角色、全身 front standing、相同比例與間距；由左至右、由上至下：neutral、gentle_smile、happy、big_laugh、excited、love、kiss_affection、shy、sad、worried、pout、surprised。只用眼眉、嘴、面頰、翼姿、身體姿勢及少量無文字像素情緒符號表達。純 #FF00FF，格與格之間留足夠裁切空間，無格線、標籤、數字、文字或白框。
```

## Emotion Board B

```text
4欄×3行、共12個同一角色、全身 front standing、相同比例與間距；由左至右、由上至下：shocked、confused、dizzy、determined、angry、frustrated、exhausted、sleepy、crying、grateful、encouragement、secretive。生氣必須兒童安全且無暴力；哭泣不可創傷化；暈眩不是受傷。純 #FF00FF，格與格之間留足夠裁切空間，無格線、標籤、數字、文字或白框。
```

## 技術後處理

模型原稿先作 chroma key 去背，再按角色 bbox 最近鄰縮放至最多 440×440，固定於 512×512 RGBA frame；腳底 bbox 固定 y=492，底部保留 20px。最後把兩幀放到 1084×552 純 #FF00FF production sheet 的 x=20 及 x=552。

