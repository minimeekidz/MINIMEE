# MM_PET_05 海浪企鵝 Pilot v001

狀態：`VISUAL REVIEW REQUIRED — 未接入正式遊戲`  
規格依據：`MINIMEE_12_PETS_SPRITE_EMOTION_CANONICAL_SPEC_v2.0.md`

## 內容

- `raw_generated/`：圖像模型第一輪原稿；約 1756×896，保留作追溯，不可直接放入 runtime。
- `production_sheets/`：四方向正式 magenta sheets；每張 1084×552。
- `runtime_frames/`：8 張已切格及去背的 512×512 RGBA PNG。
- `vision_boards/`：Board A／B，各 12 種情緒。
- `qa_previews/`：透明邊緣及地圖比例預覽，不屬 runtime 資產。

## 四方向

| Direction | Frames | Sheet |
|---|---:|---|
| front | f01、f02 | `MM_PET_05_海浪企鵝_front_walk_sheet_v001.png` |
| back | f01、f02 | `MM_PET_05_海浪企鵝_back_walk_sheet_v001.png` |
| left_side | f01、f02 | `MM_PET_05_海浪企鵝_left_side_walk_sheet_v001.png` |
| right_side | f01、f02 | `MM_PET_05_海浪企鵝_right_side_walk_sheet_v001.png` |

## Emotion Board 對照

Board A 由左至右、由上至下：

1. neutral
2. gentle_smile
3. happy
4. big_laugh
5. excited
6. love
7. kiss_affection
8. shy
9. sad
10. worried
11. pout
12. surprised

Board B 由左至右、由上至下：

13. shocked
14. confused
15. dizzy
16. determined
17. angry
18. frustrated
19. exhausted
20. sleepy
21. crying
22. grateful
23. encouragement
24. secretive

## 自動驗收結果

- 4/4 sheets：1084×552。
- 4/4 sheets：20px 外框及 20px 中央 gutter 為精確 `#FF00FF`。
- 8/8 frames：512×512 RGBA。
- 8/8 frames：alpha 只含 0／255。
- 8/8 frames：角色腳底 bbox 終點固定為 y=492，保留 20px 底部安全位。
- 身份鎖：深海藍水滴身形、白腹、短橙喙、橙腳、藍色海浪披肩、海浪腹徽章。
- 動作限制：沒有飛行姿勢。

## 尚待 Em 視覺批准

1. 角色在兩種地圖比例是否需要放大。
2. f02 抬腳幅度是否合適。
3. 背面披肩覆蓋面積是否符合角色設定。
4. Board A／B 的情緒辨識是否足夠清晰。

只有批准本 pilot 後，才批量製作其餘 11 隻。

